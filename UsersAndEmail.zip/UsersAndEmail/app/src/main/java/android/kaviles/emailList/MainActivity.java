package android.kaviles.emailList;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.kaviles.usersandemail.R;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    Button Login;
    EditText username;
    EditText password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Login =  findViewById(R.id.button2);
        username =  findViewById(R.id.tv1);
        password =  findViewById(R.id.tv2);
        username.addTextChangedListener(loginTextWatcher);
        password.addTextChangedListener(loginTextWatcher);
    }
    private TextWatcher loginTextWatcher = new TextWatcher(){
        @Override
        public void beforeTextChanged(@NonNull CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(@NonNull CharSequence s, int start, int before, int count) {

            String userNameInput = username.getText().toString().trim();
            String passwordInput = password.getText().toString().trim();
            Login.setEnabled(!userNameInput.isEmpty() && !passwordInput.isEmpty());
            Login.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent iNext = new Intent(getApplicationContext() , MainActivity2.class);
                    startActivity(iNext);
                }
            });

        }

        @Override
        public void afterTextChanged(@NonNull Editable s) {

        }
    };
}