package android.kaviles.emailList;

import androidx.appcompat.app.AppCompatActivity;

import android.kaviles.usersandemail.R;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity2 extends AppCompatActivity {
    ListView listview;
    String url = "https://jsonplaceholder.typicode.com/posts";
    private static final String TAG = "MainActivity2";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
//        TextView textView = findViewById(R.id.txtview);
        listview = findViewById(R.id.listView);
        ArrayList<String> arrayList = new ArrayList<>();
        Retrofit retrofit = new Retrofit.Builder()
                .addConverterFactory(GsonConverterFactory.create())
                .baseUrl(url)
                .build();
        JsonPlaceHolderApi jsonPlaceHolderApi = retrofit.create(JsonPlaceHolderApi.class);
        Call<List<Posts>> call = jsonPlaceHolderApi.getPosts();
        call.enqueue(new Callback<List<Posts>>() {
            @Override
            public void onResponse(Call<List<Posts>> call, Response<List<Posts>> response) {
                if (!response.isSuccessful()){
//                    textView.setText("Code"+response.code());
                    Log.d(TAG, "onResponse: Code"+response.code());
                    return;
                }
                List<Posts> posts = response.body();
                for(Posts post : posts){
                    int id = post.getId();
                    String title = post.getTitle();
                    arrayList.add(id + ": " + title);
                    ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(MainActivity2.this , android.R.layout.simple_list_item_1 , arrayList);
                    listview.setAdapter(arrayAdapter);

                }

            }

            @Override
            public void onFailure(Call<List<Posts>> call, Throwable t) {
                Log.d(TAG, "onFailure: " +t.getMessage());

            }
        });
    }
}